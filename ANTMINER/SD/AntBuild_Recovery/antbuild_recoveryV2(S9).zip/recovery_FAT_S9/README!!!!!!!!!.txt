ENGLISH:

1. Transfer all files and folders from folder RECOVERY_FAT_S9 to the SD card
2. Turn off the power and rearrange the jumpers on the control board Initially and insert the SD card with the recorded files
5. Turn on the control board with an inserted SD card and wait 60 seconds before the LEDs blink.
6. Turn off the ASIC, pull out the USB flash drive, rearrange the jumpers
7. You will see vnish firmware, if this archive does not help, you need to replace the control board.


РУССКИЙ:
1.Переносим все файлы и папки из папки RECOVERY_FAT_S9 на SD карту
2.Выключаем асик, переставляем джампера на контрольной плате и вставляем SD карту с записанным образом
3.Включаем контрольку c воткнутой SD картой и ждем 60 секунд до начала моргания светодиодов.
4.Выключаем асик , вытаскиваем флешку , переставляем джампера обратно и собираем асик
5.должна установиться vnish прошивка, если не помогло то требуется замена контрольной платы.


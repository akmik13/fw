If the license you need to read is not listed here, 
try http://www.opensource.org/licenses

If you would like it included in Cygwin as standard 
(so your package can reference it for example),
please contact the cygwin email list.
